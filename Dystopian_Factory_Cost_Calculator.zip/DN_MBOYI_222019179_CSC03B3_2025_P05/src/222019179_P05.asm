;	Author:     DN MBOYI 222019179
;	Practical Assignment 05 - Dystopian Factory Cost Calculator

.386
.MODEL FLAT ; Flat memory model
.STACK 4096 ; 4096 bytes
INCLUDE io.inc
; Exit function
ExitProcess PROTO NEAR32 stdcall, dwExitCode:DWORD

.DATA
; Global variables as required
resources DWORD 5 DUP(?) ; Array of resources
costs DWORD 5 DUP(?)     ; Array of costs

; String prompts:
strWelcome BYTE "Dystopian Factory Conglomerate Cost Calculator", 10, 0
strResources BYTE "Please enter resource amounts:", 10, 0
strCosts BYTE "Please enter resource costs:", 10, 0
strTotalCost BYTE "The total cost is ", 0
strExit BYTE "Would you like to process another set? (1=Yes, 0=No): ", 0
strDisplayResources BYTE "The resources are: ", 0
strDisplayCosts BYTE "The costs are: ", 0
strArrayValue BYTE 9, "Enter value ", 0

; Formatting strings
strNewLine BYTE 10, 0
strColon BYTE ": ", 0
strComma BYTE ", ", 0
strLeftBracket BYTE "[", 0
strRightBracket BYTE "]", 0 

.CODE
; void inputArray(int* array, int arraySize);
inputArray PROC NEAR32
    PUSH EBP
    MOV EBP, ESP 
    
    ; Save registers
    PUSH EAX
    PUSH EBX
    PUSH ECX
    PUSH EDX
    PUSHFD

    ; Parameters:
    ; [EBP + 8]  - array address
    ; [EBP + 12] - array size
    
    MOV EBX, [EBP + 8]    ; EBX = array base address
    MOV ECX, 0            ; ECX = index counter
    
inputLoop:
    CMP ECX, [EBP + 12]   ; Check if we've processed all elements
    JAE inputEnd
    
    ; Prompt for value
    INVOKE OutputStr, ADDR strArrayValue
    INVOKE OutputInt, ECX
    INVOKE OutputStr, ADDR strColon
    
    ; Get input
    INVOKE InputInt
    MOV [EBX + ECX*4], EAX ; Store input in array[index]
    
    ; Move to next element
    INC ECX
    JMP inputLoop
    
inputEnd:
    ; Restore registers and return
    POPFD
    POP EDX 
    POP ECX
    POP EBX
    POP EAX
    MOV ESP, EBP
    POP EBP
    RET 8
inputArray ENDP

; void display(int* array, int arraySize);
display PROC NEAR32
    PUSH EBP
    MOV EBP, ESP
    
    ; Save registers
    PUSH EAX
    PUSH EBX
    PUSH ECX
    PUSH EDX
    PUSHFD

    ; Parameters:
    ; [EBP + 8]  - array address
    ; [EBP + 12] - array size
    
    ; Display opening bracket
    INVOKE OutputStr, ADDR strLeftBracket
    
    MOV EBX, [EBP + 8]    ; EBX = array base address
    MOV ECX, 0            ; ECX = index counter
    
displayLoop:
    CMP ECX, [EBP + 12]   ; Check if we've processed all elements
    JAE displayEnd
    
    ; Display current element
    MOV EAX, [EBX + ECX*4]
    INVOKE OutputInt, EAX
    
    ; Add comma if not last element
    INC ECX
    CMP ECX, [EBP + 12]
    JE noComma            ; Skip comma for last element
    
    INVOKE OutputStr, ADDR strComma
    JMP displayLoop
    
noComma:
    JMP displayLoop
    
displayEnd:
    ; Display closing bracket and newline
    INVOKE OutputStr, ADDR strRightBracket
    INVOKE OutputStr, ADDR strNewLine
    
    ; Restore registers and return
    POPFD
    POP EDX
    POP ECX
    POP EBX
    POP EAX
    MOV ESP, EBP
    POP EBP
    RET 8
display ENDP

; int totalCost(int* resources, int* costs, int arraySize);
totalCost PROC NEAR32
    PUSH EBP
    MOV EBP, ESP
    
    ; Save registers
    PUSH EBX
    PUSH ECX
    PUSH EDX
    PUSHFD

    ; Parameters:
    ; [EBP + 8]  - resources array
    ; [EBP + 12] - costs array
    ; [EBP + 16] - array size
    
    MOV EAX, 0            ; EAX will hold total cost
    MOV ECX, 0            ; ECX = index counter
    
     ; Check if array size is 0
    CMP DWORD PTR [EBP + 16], 0
    JE costEnd
costLoop:
    ; Calculate resources[i] * costs[i]
    MOV EBX, [EBP + 8]    ; EBX = resources array
    MOV EDX, [EBP + 12]   ; EDX = costs array
    
    PUSH EAX              ; Save current total
    MOV EAX, [EBX + ECX*4] ; Get resources[i]
    IMUL DWORD PTR [EDX + ECX*4] ; Multiply by costs[i]
    
    ; Add to total
    POP EDX               ; Restore total to EDX
    ADD EDX, EAX          ; Add current product to total
    MOV EAX, EDX          ; Move total back to EAX
    
    ; Move to next element
    INC ECX
    CMP ECX, [EBP + 16] 
    JMP costLoop
    
costEnd:
    ; Restore registers and return
    POPFD
    POP EDX
    POP ECX
    POP EBX
    MOV ESP, EBP
    POP EBP
    RET 12
totalCost ENDP

_start:
    PUSH EBP
    MOV EBP, ESP
    SUB ESP, 4 ; Local variable for array size
    
    MOV DWORD PTR [EBP - 4], 5 ; Array size = 5
    
    ; Display welcome message
    INVOKE OutputStr, ADDR strWelcome
    INVOKE OutputStr, ADDR strNewLine
    
mainLoop:
    ; Get resource amounts
    INVOKE OutputStr, ADDR strResources
    PUSH [EBP - 4]        ; Push array size
    LEA EAX, resources    ; Get address of resources array
    PUSH EAX              ; Push array address
    CALL inputArray
    
    ; Get resource costs
    INVOKE OutputStr, ADDR strCosts
    PUSH [EBP - 4]        ; Push array size
    LEA EAX, costs        ; Get address of costs array
    PUSH EAX              ; Push array address
    CALL inputArray
    
    ; Display resource amounts
    INVOKE OutputStr, ADDR strDisplayResources
    PUSH [EBP - 4]        ; Push array size
    LEA EAX, resources    ; Get address of resources array
    PUSH EAX              ; Push array address
    CALL display
    
    ; Display resource costs
    INVOKE OutputStr, ADDR strDisplayCosts
    PUSH [EBP - 4]        ; Push array size
    LEA EAX, costs        ; Get address of costs array
    PUSH EAX              ; Push array address
    CALL display
    
    ; Calculate and display total cost
    PUSH [EBP - 4]        ; Push array size
    LEA EAX, costs        ; Get address of costs array
    PUSH EAX              ; Push costs array
    LEA EAX, resources    ; Get address of resources array
    PUSH EAX              ; Push resources array
    CALL totalCost
    
    ; Display results of the total cost:
    INVOKE OutputStr, ADDR strTotalCost
    INVOKE OutputInt, EAX
    INVOKE OutputStr, ADDR strNewLine
    INVOKE OutputStr, ADDR strNewLine
    
    ; Ask if user wants to process another set
    INVOKE OutputStr, ADDR strExit
    INVOKE InputInt
    CMP EAX, 1
    JE mainLoop           ; Loop if user entered 1
    
    ; Exit program
    MOV ESP, EBP
    POP EBP
    INVOKE ExitProcess, 0

PUBLIC _start
END
